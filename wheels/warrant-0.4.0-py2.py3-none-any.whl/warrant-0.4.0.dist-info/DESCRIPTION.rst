Python class to integrate Boto3's Cognito client so it is easy to login users. With SRP support.


